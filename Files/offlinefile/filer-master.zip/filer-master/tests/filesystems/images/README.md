The following images are JSON filesystem images created with
`tools/fs-image.js`, and named with the filesystem dir used
as the source of the image, and the version of Filer used to
generate them:

1. `tiny-fs.0.43.json` was created from `tests/filesystem/tiny-fs/` with https://github.com/filerjs/filer/blob/d66114e20c7f0235698d9933dbd90217ba86fa4e/dist/filer.min.js

If you need to create a new image, use `tools/get-filer-version.js` to
get a specific version of Filer, then `tools/fs-image.js` to generate an image.
