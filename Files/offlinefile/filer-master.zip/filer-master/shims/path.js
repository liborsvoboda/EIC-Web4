const { path } = require('../src/index');

module.exports = path;
