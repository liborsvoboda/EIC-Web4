module.exports = {
  FilerWebpackPlugin: require('../src/webpack-plugin'),
};
