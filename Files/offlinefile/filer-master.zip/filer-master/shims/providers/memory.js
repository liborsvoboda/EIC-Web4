const Memory = require('../../src/providers/memory');
module.exports = Memory;