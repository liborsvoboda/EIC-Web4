const IndexedDB = require('../../src/providers/indexeddb');
module.exports = IndexedDB;