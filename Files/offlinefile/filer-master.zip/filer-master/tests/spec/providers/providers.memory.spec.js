var util = require('../../lib/test-utils.js');
var providerBase = require('./providers.base.js');

providerBase('Memory', util.providers.Memory);
