var util = require('../../lib/test-utils.js');
var providerBase = require('./providers.base.js');

providerBase('IndexedDB', util.providers.IndexedDB);
