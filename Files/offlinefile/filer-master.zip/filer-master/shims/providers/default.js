const { Default } = require('../../src/providers/index');
module.exports = Default;